import React, { useLayoutEffect, useRef } from "react";
import myImage from "../assets/myImage.png";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import CustomCursor from "../components/CustomCursor";

gsap.registerPlugin(ScrollTrigger);

const Profile = () => {
  const profileRef = useRef(null);

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: profileRef.current,
          start: "top 80%",
          toggleActions: "play none none none",
        },
      });

      tl.from(".black-box", {
        y: 80,
        opacity: 0,
        duration: 0.8,
        ease: "power3.out",
      })
        .from(
          ".cutout",
          {
            y: 80,
            opacity: 0,
            duration: 0.7,
            ease: "power3.out",
          },
          "<"
        )
        .from(
          ".hero-title",
          {
            x: -60,
            y: 20,
            opacity: 0,
            duration: 0.8,
            ease: "power3.out",
          },
          "<"
        )
        .from(
          ".hero-text",
          {
            y: 25,
            opacity: 0,
            filter: "blur(8px)",
            duration: 0.9,
            ease: "power2.out",
          },
          "<"
        )
        .from(
          ".hero-btn",
          {
            y: 40,
            opacity: 0,
            duration: 0.6,
            ease: "power3.out",
          },
          "<"
        );
    }, profileRef);

    return () => ctx.revert();
  }, []);

  return (
    <>
      {/* CUSTOM CURSOR */}
      <CustomCursor />

      <section
        ref={profileRef}
        className="bg-primary text-black px-40"
      >
        <div className="flex gap-40 py-24">

          {/* LEFT */}
          <div>

            {/* BLACK BOX */}
            <div className="black-box group relative h-[30vh] w-[25vw] rounded-md bg-black flex justify-center items-end">

              {/* PROFILE INFO */}
              <div className="absolute top-10 left-3 opacity-0 group-hover:opacity-100 transition-all ease-in duration-150">
                <span className="block text-primary leading-none font-montaga font-semibold text-[1.5rem]">
                  Rishika Tamboli
                </span>

                <span className="block text-primary/80 uppercase font-jakarta font-light leading-none pt-1 text-[0.9rem]">
                  Web developer
                </span>
              </div>

              {/* CUTOUT */}
              <div className="cutout flex">
                <img
                  className="relative z-10 object-contain transition-transform duration-500 ease-out group-hover:translate-x-14"
                  src={myImage}
                  alt="Rishika Tamboli"
                />
              </div>
            </div>

            {/* BUTTONS */}
            <div className="flex gap-6 w-[25vw] justify-between mt-16">

              <button
                data-magnetic
                className="hero-btn w-full py-1 border border-black font-montaga"
              >
                See Work
              </button>

              <button
                data-magnetic
                className="hero-btn w-full py-1 border border-black font-montaga"
              >
                Contact
              </button>

            </div>
          </div>

          {/* RIGHT */}
          <div>

            {/* TITLE */}
            <div className="hero-title text-black text-[2.5rem] font-montaga">
              Beyond the Resume
            </div>

            {/* DESCRIPTION */}
            <p className="hero-text whitespace-pre-line pt-6 text-[1.2rem] font-inter tracking-wider">
              {`Lorem ipsum dolor sit amet consectetur adipisicing elit. Iure totam
              adipisci,aperiam numquam eligendi accusamus, inventore laborum
              error impedit asperiores reprehenderit, nisi quaerat expedita
              odio sunt consequuntur voluptate veniam quisquam explicabo
              itaque? Quibusda sequi praesentium eius eveniet asperiores,
              qui blanditiis dolores beatae nam.Repellat dicta ipsa iusto
              quos corporis, est et odit adipisci atque quia harum
              nihil laborum rem porro?`}
            </p>

          </div>
        </div>
      </section>
    </>
  );
};

export default Profile;