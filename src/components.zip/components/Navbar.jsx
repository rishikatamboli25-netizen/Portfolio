import React from 'react'
import { useState } from 'react'

const Navbar = () => {
const [selected, setSelected] = useState('Start')

    const navLinks = [
        { name: "Start", href: "/start" },
        { name: "Profile", href: "/profile" },
        { name: "Stack", href: "/stack" },
        { name: "Builds", href: "/buils" },
        { name: "Talk", href: "/talk" },
    ]

    return (
        <>
            <header className='fixed justify-self-center z-50'>
                <nav className="bg-primary  [clip-path:polygon(0_0,100%_0,100%_calc(100%_-_4px),calc(100%_-_4px)_100%,4px_100%,0_calc(100%_-_4px))] h-[5vh] w-fit px-7 text-[0.8rem] cursor-pointer">
                    <ul className='flex   h-full gap-4 w-fit mx-auto  font-jakarta font-thin uppercase'> {navLinks.map((link, index) => (
                        <li onClick={()=>setSelected(link.name)} className={`text-black h-full px-3 flex items-center  ${selected === link.name ? 'bg-black/30 text-black border-t-2 border-black' : ''}`}>{link.name}  </li>
                    ))}
                    </ul>
                </nav>
            </header>
        </>
    )
}

export default Navbar
