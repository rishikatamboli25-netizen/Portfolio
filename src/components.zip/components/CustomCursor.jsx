import React, { useEffect, useRef } from "react";
import gsap from "gsap";

const CustomCursor = () => {
  const cursorRef = useRef(null);

  useEffect(() => {
    const cursor = cursorRef.current;

    if (!cursor) return;

    const mouse = {
      x: window.innerWidth / 2,
      y: window.innerHeight / 2,
    };

    const current = {
      x: mouse.x,
      y: mouse.y,
    };

    const target = {
      x: mouse.x,
      y: mouse.y,
    };

    let raf;

    const mouseMove = (e) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    };

    const mouseDown = () => {
      gsap.to(cursor, {
        scale: 0.75,
        duration: 0.15,
        ease: "power2.out",
      });
    };

    const mouseUp = () => {
      gsap.to(cursor, {
        scale: 1,
        duration: 0.3,
        ease: "back.out(2)",
      });
    };

    const render = () => {
      const magneticButtons = document.querySelectorAll(
        "[data-magnetic]"
      );

      let closestButton = null;
      let closestDistance = Infinity;

      magneticButtons.forEach((button) => {
        const rect = button.getBoundingClientRect();

        const buttonX = rect.left + rect.width / 2;
        const buttonY = rect.top + rect.height / 2;

        const dx = buttonX - mouse.x;
        const dy = buttonY - mouse.y;

        const distance = Math.sqrt(dx * dx + dy * dy);

        // Smaller but stronger magnetic field
        const radius = 90;

        if (distance < radius && distance < closestDistance) {
          closestDistance = distance;

          closestButton = {
            x: buttonX,
            y: buttonY,
            distance,
            radius,
          };
        }
      });

      if (closestButton) {
        const strength =
          1 -
          closestButton.distance /
            closestButton.radius;

        // Strong magnetic pull
        target.x =
          mouse.x +
          (closestButton.x - mouse.x) *
            strength *
            0.95;

        target.y =
          mouse.y +
          (closestButton.y - mouse.y) *
            strength *
            0.95;
      } else {
        target.x = mouse.x;
        target.y = mouse.y;
      }

      // Faster response to magnetic pull
      current.x += (target.x - current.x) * 0.28;
      current.y += (target.y - current.y) * 0.28;

      gsap.set(cursor, {
        x: current.x,
        y: current.y,
      });

      raf = requestAnimationFrame(render);
    };

    window.addEventListener("mousemove", mouseMove);
    window.addEventListener("mousedown", mouseDown);
    window.addEventListener("mouseup", mouseUp);

    document.body.style.cursor = "none";

    render();

    return () => {
      window.removeEventListener("mousemove", mouseMove);
      window.removeEventListener("mousedown", mouseDown);
      window.removeEventListener("mouseup", mouseUp);

      document.body.style.cursor = "";

      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div
      ref={cursorRef}
      className="pointer-events-none fixed left-0 top-0 z-[9999]"
      style={{
        width: "22px",
        height: "28px",
        transform: "translate(-50%, -50%)",
      }}
    >
      <svg
        width="22"
        height="28"
        viewBox="0 0 22 28"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* White outline */}
        <path
          d="M2 1.5L19.5 17.5L11.5 18.5L16 26L12 28L7.5 20L3 25L2 1.5Z"
          fill="white"
          stroke="white"
          strokeWidth="2"
          strokeLinejoin="round"
        />

        {/* Black pointer */}
        <path
          d="M3.5 3.5L17 16.5L9.5 17.5L13.5 24.5L11.5 25.5L7.5 18.5L3.5 22.5V3.5Z"
          fill="black"
        />
      </svg>
    </div>
  );
};

export default CustomCursor;